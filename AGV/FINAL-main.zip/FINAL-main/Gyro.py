import random, pickle, time, json, math, smbus

class MPU:
    def __init__(self, gyro, acc, tau):
        # Class / object / constructor setup
        self.gz = None;
        self.az = None;
        self.gyroZcal = 0
        self.gyroYaw = 0
        self.yaw = 0

        self.dtTimer = 0
        self.tau = tau
        
        self.gyroScaleFactor = 131.0
        self.gyroHex = 0
        self.accScaleFactor = 16384.0
        self.accHex = 0
        self.bus = smbus.SMBus(1)
        time.sleep(1)
        self.address = 0x68

    def setUp(self):
        # Activate the MPU-6050
        self.bus.write_byte_data(self.address, 0x6B, 0x00)
        self.bus.write_byte_data(self.address, 0x1C, self.accHex)
        self.bus.write_byte_data(self.address, 0x1B, self.gyroHex)

    def eightBit2sixteenBit(self, reg):
        # Reads high and low 8 bit values and shifts them into 16 bit
        h = self.bus.read_byte_data(self.address, reg)
        l = self.bus.read_byte_data(self.address, reg+1)
        val = (h << 8) + l

        # Make 16 bit unsigned value to signed value (0 to 65535) to (-32768 to +32767)
        if (val >= 0x8000):
            return -((65535 - val) + 1)
        else:
            return val

    def getRawData(self):
        self.gz = self.eightBit2sixteenBit(0x47)
        self.az = self.eightBit2sixteenBit(0x3F)

    def calibrateGyro(self):
        self.gyroZcal = -10
        self.dtTimer = time.time()

    def processIMUvalues(self):
        # Update the raw data
        self.getRawData()
        self.gz -= self.gyroZcal
        self.gz /= self.gyroScaleFactor
        self.az /= self.accScaleFactor

    def compFilter(self):
        # Get the processed values from IMU
        self.processIMUvalues()
        dt = time.time() - self.dtTimer
        self.dtTimer = time.time()

        self.gyroYaw += self.gz * dt
        #self.yaw = self.gyroYaw
        return int(self.gyroYaw*10)




# Main loop
if __name__ == '__main__':
    # Set up class
    gyro = 250      # 250, 500, 1000, 2000 [deg/s]
    acc = 2        # 2, 4, 7, 16 [g]
    tau = 0.98
    mpu = MPU(gyro, acc, tau)
    mpu.setUp()
    mpu.calibrateGyro()

    while 1:   
        try:
            Gyro= mpu.compFilter()
        except OSError:
            pass
        print(Gyro)
