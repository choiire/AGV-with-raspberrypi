#!/bin/bash
sleep 20s

/bin/python /home/pi/Desktop/FINAL/RESET.py

sleep 2s

/bin/python /home/pi/Desktop/FINAL/MAIN.py