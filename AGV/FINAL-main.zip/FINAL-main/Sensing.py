import RPi.GPIO as GPIO
import time, pickle, RPi_I2C_driver, json
import numpy as np

mylcd = RPi_I2C_driver.lcd(0x3f)

sensor_data = {"vol": "25", "sonic": "20", "qr":"00", "husky":"", "lift":"0", "box":"10"}
"""
Data = "00"
with open('qr.pickle', 'wb') as f:
    pickle.dump(Data, f)"""
#with open('lift.pickle', 'wb') as f:
#    pickle.dump(0, f)
#sonic
TRIG = 21
ECHO = 20
maxTime = 0.06
#vol
AO_pin = 0
SPICLK = 11
SPIMISO = 9
SPIMOSI = 10
SPICS = 8
R1 = 300
R2 = 75

#port init
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
#sonic
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
#vol
GPIO.setup(SPIMOSI, GPIO.OUT)
GPIO.setup(SPIMISO, GPIO.IN)
GPIO.setup(SPICLK, GPIO.OUT)
GPIO.setup(SPICS, GPIO.OUT)

def readadc(adcnum, clockpin, mosipin, misopin, cspin):
        if ((adcnum > 7) or (adcnum < 0)):
                return -1
        GPIO.output(cspin, True)  
        GPIO.output(clockpin, False)  # start clock low
        GPIO.output(cspin, False)     # bring CS low

        commandout = adcnum
        commandout |= 0x18  # start bit + single-ended bit
        commandout <<= 3    # we only need to send 5 bits here
        for i in range(5):
                if (commandout & 0x80):
                        GPIO.output(mosipin, True)
                else:
                        GPIO.output(mosipin, False)
                commandout <<= 1
                GPIO.output(clockpin, True)
                GPIO.output(clockpin, False)

        adcout = 0
        # read in one empty bit, one null bit and 10 ADC bits
        for i in range(12):
                GPIO.output(clockpin, True)
                GPIO.output(clockpin, False)
                adcout <<= 1
                if (GPIO.input(misopin)):
                        adcout |= 0x1

        GPIO.output(cspin, True)
        
        adcout >>= 1       # first bit is 'null' so drop it
        
        sensor_data["vol"] = int(adcout*(5/1023)/ ( R2 / ( R1 + R2) ))

def sonic():
    GPIO.output(TRIG,True)
    time.sleep(0.00001)
    GPIO.output(TRIG,False)

    pulse_start = time.time()
    timeout = pulse_start + maxTime
    while ((GPIO.input(ECHO) == 0) and (pulse_start < timeout)):
        pulse_start = time.time()
        
    pulse_end = time.time()
    timeout = pulse_end + maxTime
    while ((GPIO.input(ECHO) == 1) and (pulse_end < timeout)):
        pulse_end = time.time()
        
    duration = pulse_end - pulse_start
    distance = int(duration * 17000)
    sensor_data["sonic"] = distance

while 1:
    sonic()
    time.sleep(0.1)
    readadc(AO_pin, SPICLK, SPIMOSI, SPIMISO, SPICS)
    time.sleep(0.1)
    try:
        with open('/home/pi/Desktop/FINAL/qr.pickle', 'rb') as f:
            sensor_data['qr'] = pickle.load(f)
        with open('/home/pi/Desktop/FINAL/husky.pickle', 'rb') as f:
            sensor_data['husky'] = pickle.load(f)
        with open('/home/pi/Desktop/FINAL/status.pickle', 'rb') as f:
            status = pickle.load(f)
            sensor_data['lift'] = status["lift"]
            sensor_data['box'] = status["box"]
        with open('/home/pi/Desktop/FINAL/sensor.pickle', 'wb') as f:
            pickle.dump(sensor_data, f)
    except EOFError:
            pass
    if sensor_data["vol"] == 25:
        vol_per = "100% [###]"
    elif sensor_data["vol"] < 24:
        vol_per = " 70% [ ##]"
    elif sensor_data["vol"] < 23:
        vol_per = " 30% [  #]"
    else:
        vol_per = "ERROR"
    try:
        mylcd.lcd_display_string("Sonic: %scm     " % sensor_data["sonic"],1)
        time.sleep(0.01)
        mylcd.lcd_display_string("Vol: %s  " %  vol_per,2)
        time.sleep(0.01)
    except OSError:
        time.sleep(0.1)
        
    #print(sensor_data)