import json, time, pickle
#from urllib import parse
from flask import Flask, json, jsonify, request, abort, make_response, render_template

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

f = open('SENSOR.json',"r")
sensor_data = f.read()
f.close()

with open('sensor.pickle', 'wb') as f:
        pickle.dump(json.loads(sensor_data), f)

ff = open('QR.json',"r")
qr_data = ff.read()
ff.close()

with open('qr.pickle', 'wb') as ff:
        pickle.dump(json.loads(qr_data), ff)
# 읽기
#with open('sensor.pickle', 'rb') as f:
#        sensor_data = pickle.load(f)

##############################################################
# https://choiseokwon.tistory.com/210

# Time Complexity는 H에 따라 다르다.
# O(b^d), where d = depth, b = 각 노드의 하위 요소 수
# heapque를 이용하면 길을 출력할 때 reverse를 안해도 됨

class Node:
    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0
        self.h = 0
        self.f = 0

    def __eq__(self, other):
        return self.position == other.position

def heuristic(node, goal, D=1, D2=2 ** 0.5):  # Diagonal Distance
    dx = abs(node.position[0] - goal.position[0])
    dy = abs(node.position[1] - goal.position[1])
    return D * (dx + dy) + (D2 - 2 * D) * min(dx, dy)
    
def aStar(maze, start, end):
    # startNode와 endNode 초기화
    startNode = Node(None, start)
    endNode = Node(None, end)

    # openList, closedList 초기화
    openList = []
    closedList = []

    # openList에 시작 노드 추가
    openList.append(startNode)

    # endNode를 찾을 때까지 실행
    while openList:

        # 현재 노드 지정
        currentNode = openList[0]
        currentIdx = 0

        # 이미 같은 노드가 openList에 있고, f 값이 더 크면
        # currentNode를 openList안에 있는 값으로 교체
        for index, item in enumerate(openList):
            if item.f < currentNode.f:
                currentNode = item
                currentIdx = index

        # openList에서 제거하고 closedList에 추가
        openList.pop(currentIdx)
        closedList.append(currentNode)

        # 현재 노드가 목적지면 current.position 추가하고
        # current의 부모로 이동
        if currentNode == endNode:
            path = []
            current = currentNode
            while current is not None:
                # maze 길을 표시하려면 주석 해제
                # x, y = current.position
                # maze[x][y] = 7 
                path.append(current.position)
                current = current.parent
            return path[::-1]  # reverse

        children = []
        # 인접한 xy좌표 전부
        for newPosition in [(0, -1), (0, 1), (-1, 0), (1, 0)]:#[(0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1)]:

            # 노드 위치 업데이트
            nodePosition = (
                currentNode.position[0] + newPosition[0],  # X
                currentNode.position[1] + newPosition[1])  # Y
                
            # 미로 maze index 범위 안에 있어야함
            within_range_criteria = [
                nodePosition[0] > (len(maze) - 1),
                nodePosition[0] < 0,
                nodePosition[1] > (len(maze[len(maze) - 1]) - 1),
                nodePosition[1] < 0,
            ]

            if any(within_range_criteria):  # 하나라도 true면 범위 밖임
                continue

            # 장애물이 있으면 다른 위치 불러오기
            if maze[nodePosition[0]][nodePosition[1]] != 0:
                continue

            new_node = Node(currentNode, nodePosition)
            children.append(new_node)

        # 자식들 모두 loop
        for child in children:

            # 자식이 closedList에 있으면 continue
            if child in closedList:
                continue

            # f, g, h값 업데이트
            child.g = currentNode.g + 1
            child.h = ((child.position[0] - endNode.position[0]) ) + ((child.position[1] - endNode.position[1]) ** 2)
            #child.h = ((child.position[0] - endNode.position[0]) **
            #           2) + ((child.position[1] - endNode.position[1]) ** 2)
            #child.h = heuristic(child, endNode) #다른 휴리스틱
            # print("position:", child.position) 거리 추정 값 보기
            # print("from child to goal:", child.h)
            
            child.f = child.g + -child.h

            # 자식이 openList에 있으고, g값이 더 크면 continue
            if len([openNode for openNode in openList
                    if child == openNode and child.g > openNode.g]) > 0:
                continue
                    
            openList.append(child)
        
##############################################################

@app.route('/') #메인 화면
def welcome():
    return render_template('index.html')

@app.route('/post', methods=['POST']) #외부에서 서버로 값 전달
def post_json():
    sensor_data = json.loads(request.get_json())
    with open('sensor.pickle', 'wb') as f:
        pickle.dump(sensor_data, f)
    return jsonify(json.dumps(sensor_data))

@app.route('/get', methods=['GET']) #서버에서 외부로 센서 값 전달
def get():
    with open('sensor.pickle', 'rb') as f:
        sensor_data = pickle.load(f)
    return jsonify(json.dumps(sensor_data))

@app.route('/getall', methods=['GET']) #서버에서 외부로 전체 값 전달
def getall():
    with open('sensor.pickle', 'rb') as f:
        sensor_data = pickle.load(f)
    with open('qr.pickle', 'rb') as f:
        qr_data = pickle.load(f)
    merged = {**sensor_data,**qr_data}
    return jsonify(json.dumps(merged))
    #return jsonify(json.dumps(sensor_data.update(qr_data)))

@app.route('/qrroute', methods=['GET']) #서버에서 외부로 경로 값 전달
def get_qr_data():
    with open('qr.pickle', 'rb') as f:
        qr_data = pickle.load(f)
    
    return jsonify(json.dumps(qr_data["route"]))

@app.route('/qractuator', methods=['GET']) #서버에서 외부로 짐을 들 것인지 전달
def get_qr():
    with open('qr.pickle', 'rb') as f:
        qr_data = pickle.load(f)
    
    return jsonify(json.dumps(qr_data["actuator"]))

@app.route('/reset', methods=['GET']) #센서값 리셋
def get_reset():
    f = open('SENSOR.json',"r")
    sensor_data1 = f.read()
    sensor_data = json.loads(sensor_data1)
    f.close()

    with open('sensor.pickle', 'wb') as f:
        pickle.dump(sensor_data, f)

    ff = open('QR.json',"r")
    qr_data1 = ff.read()
    qr_data = json.loads(qr_data1)
    ff.close()

    with open('qr.pickle', 'wb') as ff:
        pickle.dump(qr_data, ff)
    
    merged = {**sensor_data,**qr_data}
    return jsonify(json.dumps(merged))

@app.route('/move/<qr_end1>/<int:actuator>/<int:map>', methods=['GET']) #외부에서 서버로 경로값 계산 청요청
def Astar_move(qr_end1,actuator,map):
    with open('sensor.pickle', 'rb') as f:
        sensor_data = pickle.load(f)
    with open('qr.pickle', 'rb') as ff:
        qr_data = pickle.load(ff)
    
    maze3 = [[0,0,0], #3*3 맵 리스트
             [0,0,0],
             [0,0,0]]
        
    maze4 = [[0,0,0,0], #4*4 맵 리스트
             [0,0,0,0],
             [0,0,0,0],
             [0,0,0,0]]
    
    if int(map) == 3:
        maze = maze3
    elif int(map) == 4:
        maze = maze4
        
    start1 = ["",""]
    start1[0] = int(sensor_data["qr"][0])
    start1[1] = int(sensor_data["qr"][1])
    start = tuple(start1)

    qr_end = str(qr_end1)
    end1 = ["",""]
    end1[0] = int(qr_end[1])
    end1[1] = int(qr_end[2])
    end = tuple(end1)
    """ #짐이 여러개일경우 짐을 들었을 경우와 안들었을 경우를 따로 계산
    if int(sensor_data["lift"]) == 0:
        path = aStar(maze, start, end)
        lst = [list(row) for row in path]
        print(lst)
        a =[]
        for i in lst:
            line = []
            a.append(str(i[0])+str(i[1]))
        qr_data["route"] = a
        qr_data["actuator"] = lift
        
    if int(sensor_data["lift"]) == 1:
        x = int(qr_data["qrbox"][1])
        y = int(qr_data["qrbox"][0])
        maze[y][x] = 1"""
    path = aStar(maze, start, end)
    lst = [list(row) for row in path]
    print(lst)
    a =[]
    for i in lst:
        line = []
        a.append(str(i[0])+str(i[1]))
    qr_data["route"] = a
    qr_data["actuator"] = actuator
        
    with open('qr.pickle', 'wb') as fff:
        pickle.dump(qr_data, fff)
    
    return jsonify(qr_data)

